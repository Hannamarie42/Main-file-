for i in {1..2000}; do printf ' hello digital love languages 🍒 👈 👇 👉 🖐 👉 🦋 🦎 🌹 🥀 🌺 🐉 🌗 🌘 🌑 🌒 🌓 🌔 🌱 🌷 🌱 🌸 🌱 💦 🌱 🍄 🌱 🌷 🌹 🌻 🌼 🌺 🌸 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 '; done;
