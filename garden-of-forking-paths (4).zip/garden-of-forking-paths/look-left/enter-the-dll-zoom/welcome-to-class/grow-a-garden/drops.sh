for i in {1..2000}; do printf ' ♡💧🩸💧💧💧💧💻<>💻💧💧💧💧🩸💧♡ '; done;
